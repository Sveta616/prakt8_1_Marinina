class Cinema(_zal:Int) {
    var name="Unnamed"
    var seans="Unnamed"
    var price=0.0
    var zal=0
    init{
        zal=_zal
    }
    var kzr=0
    var zh="Unnamed"
    var zal2="Ваш зал"
    fun Input(cinema:Cinema)
    {
        try
        {
            println("Введите название фильма")
            cinema.name = readLine()!!.toString()
            do {

                    println("Введите какой сеанс(Утренний, Дневной, Вечерний)")
                    cinema.seans= readLine()!!.toString()

            }while(!(cinema.seans=="Утренний") && !(cinema.seans=="Дневной" ) && !(cinema.seans=="Вечерний"))
            do{
                println("Введите стоимость билета")
                cinema.price= readLine()!!.toDouble()
            }while(cinema.price<=0)

            do
            {
                println("Введите кол-во зрителей")
                cinema.kzr= readLine()!!.toInt()
            }while(cinema.kzr<=0)

        }
        catch(e:Exception)
        {
            println("Введите ещё раз, введено неккоректно")
        }
    }
    fun Output(cinema:Cinema)
    {
        println("Название фильма=${cinema.name}")
        println("Сеанс=${cinema.seans}")
        println("Стоимость билета=${cinema.price}")
        println("Кол-во залов=${cinema.zal}")
        println("Кол-во зрителей=${cinema.kzr}")
    }
    fun Sckidka(cinema:Cinema)
    {
        if (cinema.seans=="Утренний")
            cinema.price=cinema.price*0.9
    }
    fun Zal(cinema:Cinema)
    {
        if (cinema.price>500)
        {
         println("${cinema.zal2}=Вип")
        }
        else {
            println("${cinema.zal2}=Эконом")
        }
    }
    fun Zhanr(cinema:Cinema)
    {

        do {

                println("Выберите жанр кино(Романтика, Ужасы, Приключения)")
            cinema.zh= readLine()!!.toString()

        }while(!(cinema.zh=="Романтика") && !(cinema.zh=="Ужасы" ) && !(cinema.zh=="Приключения"))
    }

}
