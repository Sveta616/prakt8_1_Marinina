fun main()
{
    try {
        var cinema=Cinema(15)
        cinema.Input(cinema)
        cinema.Zhanr(cinema)
        cinema.Zal(cinema)
        cinema.Sckidka(cinema)
        cinema.Output(cinema)



    }
    catch(e:Exception)
    {
       println("Данные введены неверно")
    }
}